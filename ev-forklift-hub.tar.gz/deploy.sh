#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 开始部署 EV-Forklift-Hub...${NC}"

# 检查 Docker 是否安装
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker 未安装，请先安装 Docker${NC}"
    exit 1
fi

# 检查 Docker Compose 是否安装
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}❌ Docker Compose 未安装，请先安装 Docker Compose${NC}"
    exit 1
fi

# 拉取最新代码
echo -e "${YELLOW}📥 拉取最新代码...${NC}"
git pull origin main

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ 拉取代码失败${NC}"
    exit 1
fi

# 停止旧服务
echo -e "${YELLOW}🛑 停止旧服务...${NC}"
docker-compose down

# 重新构建并启动
echo -e "${YELLOW}🔨 构建并启动服务...${NC}"
docker-compose up -d --build

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ 部署失败${NC}"
    exit 1
fi

# 等待服务启动
echo -e "${YELLOW}⏳ 等待服务启动（30秒）...${NC}"
sleep 30

# 检查服务状态
echo -e "${YELLOW}✅ 检查服务状态...${NC}"
docker-compose ps

# 显示日志
echo -e "${YELLOW}📋 最近日志：${NC}"
docker-compose logs --tail=20

echo -e "${GREEN}🎉 部署完成！${NC}"
echo -e "${GREEN}访问地址：http://$(hostname -I | awk '{print $1}')${NC}"
